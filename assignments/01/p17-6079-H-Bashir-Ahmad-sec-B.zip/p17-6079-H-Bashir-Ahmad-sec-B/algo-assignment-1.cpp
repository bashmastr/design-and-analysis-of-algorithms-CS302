#include <iostream> 
#include <sstream> 
#include <string>
using namespace std; 

class divid_and_conqure{

    public:

    int string_to_int(string var){
    
        stringstream geek(var); 
        int x = 0; 
        geek >> x;  
        return x;
    }


    int multipler(string var1, string var2){

        int temp1 = string_to_int(var1);
        int temp2 = string_to_int(var2);
        return temp1 * temp2;
    }

    int shift_zeros(int var, int zeros){
        for (int i = 0; i < zeros; i++){
            var = var * 10;
        }

        return var;
    }

    void divide_conquer(string  multipicand, string multipler){

        int sum = 0,j;
        int len_Mcand = multipicand.length();
        int len_Mpler = multipler.length();
        int shift = 0;

        string var,str1,str2,str3;

        if (len_Mcand % 2 != 0){
            multipicand = "0" + multipicand;
            len_Mcand = multipicand.length();
        } 

        for (int i = 0; i < len_Mcand; i += 2 ){

            str1 = multipicand[i];
            str1 = str1 + multipicand[i+1];

            for (int j = 0; j < len_Mpler; j += 2){

                str2 = multipler[j];
                str2 = str2 + multipler[j+1];

                shift =  (len_Mcand) - (i+2);
                shift = shift + (len_Mpler) - (j+2);

                int temp1 = string_to_int(str1);
                int temp2 = string_to_int(str2);
                int z = temp1 * temp2;
            
                sum = sum+ (shift_zeros(z,shift));
            
            } 
        }
        cout<<sum<<endl;
    }
};

  
int main() { 
    divid_and_conqure d;
    string var1,var2;
    cout<<"enter value 1 : \n";
    cin>>var1;
    cout<<"enter value 2 : \n";
    cin>>var2;

    cout<<"Answere : ";
    d.divide_conquer(var1,var2);    
   
    return 0; 
}